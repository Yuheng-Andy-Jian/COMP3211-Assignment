library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_pipelined_core is
-- Testbench has no ports
end tb_pipelined_core;

architecture behavior of tb_pipelined_core is

    -- Component Declaration for the Unit Under Test (UUT)
    component single_cycle_core
    port(
         clk   : in  std_logic;
         reset : in  std_logic;
         btnC  : in  std_logic; -- Manual step button
         sw    : in  std_logic_vector(15 downto 0);
         led   : out std_logic_vector(15 downto 0);
         seg   : out std_logic_vector(6 downto 0);
         an    : out std_logic_vector(3 downto 0)
        );
    end component;

    -- Inputs
    signal clk   : std_logic := '0';
    signal reset : std_logic := '0';
    signal btnC  : std_logic := '0';
    signal sw    : std_logic_vector(15 downto 0) := (others => '0');

    -- Outputs
    signal led   : std_logic_vector(15 downto 0);
    signal seg   : std_logic_vector(6 downto 0);
    signal an    : std_logic_vector(3 downto 0);

    -- Clock period definition (100 MHz)
    constant clk_period : time := 10 ns;

begin

    -- Instantiate the Unit Under Test (UUT)
    uut: single_cycle_core port map (
          clk => clk,
          reset => reset,
          btnC => btnC,
          sw => sw,
          led => led,
          seg => seg,
          an => an
        );

    -- Clock process definitions
    clk_process :process
    begin
        clk <= '0';
        wait for clk_period/2;
        clk <= '1';
        wait for clk_period/2;
    end process;

    -- Stimulus process
    stim_proc: process
    
        -- Helper procedure to simulate a button press 
        -- (Holds btnC high for 15 cycles to beat the 10-cycle debouncer)
        procedure press_step_button is
        begin
            btnC <= '1';
            wait for clk_period * 15; 
            btnC <= '0';
            wait for clk_period * 15; -- Wait for pipeline to settle
        end procedure;

    begin		
        -- 1. Initialize System
        reset <= '1';
        wait for clk_period * 10;
        reset <= '0';
        wait for clk_period * 10;

        -- 2. Load Register $1 (IN $1, SW)
        sw <= x"0010";          -- Set switches to Hex 0010
        press_step_button;      -- Fetch IN $1
        press_step_button;      -- Move to Decode
        press_step_button;      -- Move to Execute
        press_step_button;      -- Move to Memory
        press_step_button;      -- Move to Write-Back (Data loaded!)

        -- 3. Load Register $2 (IN $2, SW)
        sw <= x"0020";          -- Set switches to Hex 0020
        press_step_button;      -- Fetch IN $2
        press_step_button;      -- Move to Decode
        press_step_button;      -- Move to Execute
        press_step_button;      -- Move to Memory
        press_step_button;      -- Move to Write-Back (Data loaded!)

        -- 4. Execute Custom Instruction (DIS)
        -- At this point, DIS is fetched. We step to push it to Execute.
        press_step_button;      -- Fetch DIS
        press_step_button;      -- Decode DIS
        press_step_button;      -- Execute DIS (FLAG LED 15 should turn ON here!)

        -- 5. Branch Evaluation & Control Hazard Flush (BNE)
        press_step_button;      -- Fetch BNE 
        press_step_button;      -- Fetch Dummy ADD 1 / Decode BNE
        press_step_button;      -- Fetch Dummy ADD 2 / Execute BNE
        
        -- In this next step, BNE hits Memory, evaluates TAKEN, and flushes!
        press_step_button;      -- The dummy ADDs become 0000 (NOPs)

        -- 6. The Branch Target & Final Output (OUT)
        press_step_button;      -- Fetch OUT (Target of the branch)
        press_step_button;      -- Decode OUT
        press_step_button;      -- Execute OUT
        press_step_button;      -- Memory OUT
        press_step_button;      -- Write-Back OUT (LEDs 14 down to 0 should show 0010!)
        
        press_step_button;
        -- Add a few extra steps just to let the final signals settle on the waveform
        press_step_button;
        press_step_button;

        -- End Simulation
        wait;
    end process;

end behavior;
      
      
      
      