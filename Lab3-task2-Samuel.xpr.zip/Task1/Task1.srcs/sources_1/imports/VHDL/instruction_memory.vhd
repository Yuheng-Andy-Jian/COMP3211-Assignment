---------------------------------------------------------------------------
-- instruction_memory.vhd - Implementation of A Single-Port, 16 x 16-bit
--                          Instruction Memory.
-- 
-- Notes: refer to headers in single_cycle_core.vhd for the supported ISA.
--
-- Copyright (C) 2006 by Lih Wen Koh (lwkoh@cse.unsw.edu.au)
-- All Rights Reserved. 
--
-- The single-cycle processor core is provided AS IS, with no warranty of 
-- any kind, express or implied. The user of the program accepts full 
-- responsibility for the application of the program and the use of any 
-- results. This work may be downloaded, compiled, executed, copied, and 
-- modified solely for nonprofit, educational, noncommercial research, and 
-- noncommercial scholarship purposes provided that this notice in its 
-- entirety accompanies all copies. Copies of the modified software can be 
-- delivered to persons who use it solely for nonprofit, educational, 
-- noncommercial research, and noncommercial scholarship purposes provided 
-- that this notice in its entirety accompanies all copies.
--
---------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity instruction_memory is
    port ( reset    : in  std_logic;
           clk      : in  std_logic;
           addr_in  : in  std_logic_vector(3 downto 0);
           insn_out : out std_logic_vector(15 downto 0) );
end instruction_memory;

architecture behavioral of instruction_memory is

type mem_array is array(0 to 15) of std_logic_vector(15 downto 0);
signal sig_insn_mem : mem_array;

begin
    mem_process: process ( clk,
                           addr_in ) is
  
    variable var_insn_mem : mem_array;
    variable var_addr     : integer;
  
    begin
        if (reset = '1') then
        -- TEST PROGRAM FOR LAB 3 TASK 1 (BNE & DIS)
        -- Assume registers $1 and $2 get loaded with different values from the switches
        -- insn_0 : IN   $1, SW      (Opcode 6) - Load first switch value into $1
        -- insn_1 : IN   $2, SW      (Opcode 6) - Load second switch value into $2
        
        -- Test DIS: DIS $2, $1, 5   (Opcode 7 | Rs=1 | Rt=2 | imm=5)
        -- insn_2 : DIS  $2, $1, 5   -> Expect COP1 = $1 + 5, COP2 = $2, FLAG = 1
        
        -- Test BNE: BNE $1, $2, 2   (Opcode 2 | Rs=1 | Rt=2 | imm=2)
        -- insn_3 : BNE  $1, $2, 2   -> Since $1 != $2, Jump to (PC + 1) + 2 = Address 6
        
        -- These instructions should be SKIPPED if BNE works!
        -- insn_4 : ADD  $3, $1, $1  (Opcode 8)
        -- insn_5 : ADD  $3, $2, $2  (Opcode 8)
        
        -- Branch Target
        -- insn_6 : OUT  $1, LED     (Opcode 5) - Output $1 to LEDs to prove we made it here!

            var_insn_mem(0)  := X"6010"; -- 1. IN $1, SW
            var_insn_mem(1)  := X"0000"; -- NOP (Buffer to let you change switches)
            var_insn_mem(2)  := X"0000"; -- NOP
            var_insn_mem(3)  := X"0000"; -- NOP
            var_insn_mem(4)  := X"6020"; -- 2. IN $2, SW
            var_insn_mem(5)  := X"0000"; -- NOP
            var_insn_mem(6)  := X"0000"; -- NOP
            var_insn_mem(7)  := X"0000"; -- NOP
            var_insn_mem(8)  := X"7125"; -- 3. DIS $2, $1, 5
            var_insn_mem(9)  := X"2122"; -- 4. BNE $1, $2, 2 (Branch offset = +2)
            var_insn_mem(10) := X"8113"; -- 5. ADD (Should be FLUSHED/SKIPPED)
            var_insn_mem(11) := X"8223"; -- 6. ADD (Should be FLUSHED/SKIPPED)
            var_insn_mem(12) := X"5010"; -- 7. OUT $1, LED (Branch Target!)
            var_insn_mem(13) := X"0000"; -- NOP
            var_insn_mem(14) := X"0000"; -- NOP
            var_insn_mem(15) := X"0000"; -- NOP
                
        elsif (rising_edge(clk)) then
            -- read instructions on the rising clock edge
            var_addr := conv_integer(addr_in);
            insn_out <= var_insn_mem(var_addr);
        end if;

        -- the following are probe signals (for simulation purpose)
        sig_insn_mem <= var_insn_mem;

    end process;
  
end behavioral;
