---------------------------------------------------------------------------
-- single_cycle_core.vhd - A Single-Cycle Processor Implementation
--
-- Notes : 
--
-- See single_cycle_core.pdf for the block diagram of this single
-- cycle processor core.
--
-- Instruction Set Architecture (ISA) for the single-cycle-core:
--   Each instruction is 16-bit wide, with four 4-bit fields.
--
--     noop      
--        # no operation or to signal end of program
--        # format:  | opcode = 0 |  0   |  0   |   0    | 
--
--     load  rt, rs, offset     
--        # load data at memory location (rs + offset) into rt
--        # format:  | opcode = 1 |  rs  |  rt  | offset |
--
--     store rt, rs, offset
--        # store data rt into memory location (rs + offset)
--        # format:  | opcode = 3 |  rs  |  rt  | offset |
--
--     add   rd, rs, rt
--        # rd <- rs + rt
--        # format:  | opcode = 8 |  rs  |  rt  |   rd   |
--
--
-- Copyright (C) 2006 by Lih Wen Koh (lwkoh@cse.unsw.edu.au)
-- All Rights Reserved. 
--
-- The single-cycle processor core is provided AS IS, with no warranty of 
-- any kind, express or implied. The user of the program accepts full 
-- responsibility for the application of the program and the use of any 
-- results. This work may be downloaded, compiled, executed, copied, and 
-- modified solely for nonprofit, educational, noncommercial research, and 
-- noncommercial scholarship purposes provided that this notice in its 
-- entirety accompanies all copies. Copies of the modified software can be 
-- delivered to persons who use it solely for nonprofit, educational, 
-- noncommercial research, and noncommercial scholarship purposes provided 
-- that this notice in its entirety accompanies all copies.
--
---------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity single_cycle_core is
    port ( reset  : in  std_logic;
           clk    : in  std_logic;
           btnC   : in  std_logic;
           sw     : in  std_logic_vector(15 downto 0);
           led    : out std_logic_vector(15 downto 0);
           seg    : out std_logic_vector(6 downto 0); 
           an     : out std_logic_vector(3 downto 0));
end single_cycle_core;



architecture structural of single_cycle_core is

component seven_seg_controller is
    port ( clk     : in  std_logic;
           data_in : in  std_logic_vector(15 downto 0);
           seg     : out std_logic_vector(6 downto 0);
           an      : out std_logic_vector(3 downto 0) );
end component;

component program_counter is
    port ( reset    : in  std_logic;
           clk      : in  std_logic;
           addr_in  : in  std_logic_vector(3 downto 0);
           addr_out : out std_logic_vector(3 downto 0) );
end component;

component instruction_memory is
    port ( reset    : in  std_logic;
           clk      : in  std_logic;
           addr_in  : in  std_logic_vector(3 downto 0);
           insn_out : out std_logic_vector(15 downto 0) );
end component;

component sign_extend_4to16 is
    port ( data_in  : in  std_logic_vector(3 downto 0);
           data_out : out std_logic_vector(15 downto 0) );
end component;

component mux_2to1_4b is
    port ( mux_select : in  std_logic;
           data_a     : in  std_logic_vector(3 downto 0);
           data_b     : in  std_logic_vector(3 downto 0);
           data_out   : out std_logic_vector(3 downto 0) );
end component;

component mux_2to1_16b is
    port ( mux_select : in  std_logic;
           data_a     : in  std_logic_vector(15 downto 0);
           data_b     : in  std_logic_vector(15 downto 0);
           data_out   : out std_logic_vector(15 downto 0) );
end component;

component control_unit is
    port ( opcode     : in  std_logic_vector(3 downto 0);
           reg_dst    : out std_logic;
           reg_write  : out std_logic;
           alu_src    : out std_logic;
           mem_write  : out std_logic;
           mem_to_reg : out std_logic;
           in_to_reg  : out std_logic;
           led_write  : out std_logic;
           sat_enable : out std_logic; 
           branch_bne : out std_logic;
           dis_write  : out std_logic );
end component;

component register_file is
    port ( reset           : in  std_logic;
           clk             : in  std_logic;
           read_register_a : in  std_logic_vector(3 downto 0);
           read_register_b : in  std_logic_vector(3 downto 0);
           write_enable    : in  std_logic;
           write_register  : in  std_logic_vector(3 downto 0);
           write_data      : in  std_logic_vector(15 downto 0);
           read_data_a     : out std_logic_vector(15 downto 0);
           read_data_b     : out std_logic_vector(15 downto 0) );
end component;

component adder_4b is
    port ( src_a     : in  std_logic_vector(3 downto 0);
           src_b     : in  std_logic_vector(3 downto 0);
           sum       : out std_logic_vector(3 downto 0);
           carry_out : out std_logic );
end component;

component adder_16b is
    port ( src_a     : in  std_logic_vector(15 downto 0);
           src_b     : in  std_logic_vector(15 downto 0);
           sat_enable: in  std_logic;
           sum       : out std_logic_vector(15 downto 0);
           carry_out : out std_logic );
end component;

component data_memory is
    port ( reset        : in  std_logic;
           clk          : in  std_logic;
           write_enable : in  std_logic;
           write_data   : in  std_logic_vector(15 downto 0);
           addr_in      : in  std_logic_vector(3 downto 0);
           data_out     : out std_logic_vector(15 downto 0) );
end component;

signal sig_next_pc              : std_logic_vector(3 downto 0);
signal sig_curr_pc              : std_logic_vector(3 downto 0);
signal sig_one_4b               : std_logic_vector(3 downto 0);
signal sig_pc_carry_out         : std_logic;
signal sig_insn                 : std_logic_vector(15 downto 0);
signal sig_sign_extended_offset : std_logic_vector(15 downto 0);
signal sig_reg_dst              : std_logic;
signal sig_reg_write            : std_logic;
signal sig_alu_src              : std_logic;
signal sig_mem_write            : std_logic;
signal sig_mem_to_reg           : std_logic;
signal sig_write_register       : std_logic_vector(3 downto 0);
signal sig_write_data           : std_logic_vector(15 downto 0);
signal sig_read_data_a          : std_logic_vector(15 downto 0);
signal sig_read_data_b          : std_logic_vector(15 downto 0);
signal sig_alu_src_b            : std_logic_vector(15 downto 0);
signal sig_alu_result           : std_logic_vector(15 downto 0); 
signal sig_alu_carry_out        : std_logic;
signal sig_data_mem_out         : std_logic_vector(15 downto 0);
signal sig_in_to_reg            : std_logic;
signal sig_mem_mux_out          : std_logic_vector(15 downto 0);
signal sig_led_write            : std_logic;
signal sig_sat_enable           : std_logic;
signal sig_branch_bne           : std_logic;
signal sig_bne_not_equal        : std_logic;
signal sig_bne_taken            : std_logic;
signal sig_branch_target        : std_logic_vector(3 downto 0);
signal sig_pc_in                : std_logic_vector(3 downto 0);
signal sig_dis_write            : std_logic;
signal sig_cop1                 : std_logic_vector(15 downto 0);
signal sig_cop2                 : std_logic_vector(15 downto 0);
signal sig_flag                 : std_logic := '0';

-- Data Hazard
signal sig_stall                : std_logic;
signal sig_hazard_rs            : std_logic;
signal sig_hazard_rt            : std_logic;

-- IF/ID Pipeline Register
signal if_id_pc                 : std_logic_vector(3 downto 0);
signal if_id_insn               : std_logic_vector(15 downto 0);

-- ID/EX Pipeline Register
signal id_ex_pc                 : std_logic_vector(3 downto 0);
signal id_ex_read_data_a        : std_logic_vector(15 downto 0);
signal id_ex_read_data_b        : std_logic_vector(15 downto 0);
signal id_ex_imm                : std_logic_vector(15 downto 0);
signal id_ex_write_reg          : std_logic_vector(3 downto 0);
-- ID/EX Control Signals
signal id_ex_ctrl_reg_write     : std_logic;
signal id_ex_ctrl_mem_to_reg    : std_logic;
signal id_ex_ctrl_mem_write     : std_logic;
signal id_ex_ctrl_alu_src       : std_logic;
signal id_ex_ctrl_branch        : std_logic;
signal id_ex_ctrl_sat_enable    : std_logic;
signal id_ex_ctrl_in_to_reg     : std_logic;
signal id_ex_ctrl_dis_write     : std_logic;
-- EX/MEM Pipeline Register
signal ex_mem_alu_result        : std_logic_vector(15 downto 0);
signal ex_mem_read_data_b       : std_logic_vector(15 downto 0);
signal ex_mem_write_reg         : std_logic_vector(3 downto 0);
signal ex_mem_branch_target     : std_logic_vector(3 downto 0);
signal ex_mem_bne_taken         : std_logic;
-- EX/MEM Control Signals
signal ex_mem_ctrl_reg_write    : std_logic;
signal ex_mem_ctrl_mem_to_reg   : std_logic;
signal ex_mem_ctrl_mem_write    : std_logic;
signal ex_mem_ctrl_in_to_reg    : std_logic;

-- MEM/WB Pipeline Register
signal mem_wb_alu_result        : std_logic_vector(15 downto 0);
signal mem_wb_mem_data          : std_logic_vector(15 downto 0);
signal mem_wb_write_reg         : std_logic_vector(3 downto 0);
-- MEM/WB Control Signals
signal mem_wb_ctrl_reg_write    : std_logic;
signal mem_wb_ctrl_mem_to_reg   : std_logic;
signal mem_wb_ctrl_in_to_reg    : std_logic;

signal sig_pc_stall_out         : std_logic_vector(3 downto 0);
signal sig_btn_sync_1           : std_logic := '0';
signal sig_btn_sync_2           : std_logic := '0';
signal sig_btn_last             : std_logic := '0';
signal sig_step_pulse           : std_logic := '0';
signal id_ex_ctrl_led_write  : std_logic;
signal ex_mem_ctrl_led_write : std_logic;
signal mem_wb_ctrl_led_write : std_logic;
signal mem_wb_read_data_b : std_logic_vector(15 downto 0);
signal sig_freeze_pc            : std_logic;
signal debounce_counter : integer range 0 to 1000000 := 0;
signal sig_btn_clean    : std_logic := '0';
signal sig_reg_write_gated      : std_logic;
begin

    sig_one_4b <= "0001";
    sig_bne_not_equal <= '1' when id_ex_read_data_a /= id_ex_read_data_b else '0';
    sig_bne_taken     <= id_ex_ctrl_branch and sig_bne_not_equal;
    sig_hazard_rs <= '1' when (id_ex_ctrl_reg_write = '1') and (id_ex_write_reg /= "0000") and (id_ex_write_reg = if_id_insn(11 downto 8)) else '0';
    sig_hazard_rt <= '1' when (id_ex_ctrl_reg_write = '1') and (id_ex_write_reg /= "0000") and (id_ex_write_reg = if_id_insn(7 downto 4)) else '0';
    sig_stall <= '1' when (if_id_insn(15 downto 12) = "0010") and (sig_hazard_rs = '1' or sig_hazard_rt = '1') else '0';
    sig_freeze_pc <= '1' when (sig_stall = '1' or sig_step_pulse = '0') else '0';
    sig_reg_write_gated <= mem_wb_ctrl_reg_write and sig_step_pulse;
    display_controller : seven_seg_controller
    port map ( clk     => clk,
               data_in => if_id_insn, -- Display the instruction in the ID stage!
               seg     => seg,
               an      => an );
-- Instruction Fetch (IF) Stage
    pc : program_counter
    port map ( reset    => reset,
               clk      => clk,
               addr_in  => sig_pc_stall_out,
               addr_out => sig_curr_pc ); 

    next_pc : adder_4b 
    port map ( src_a     => sig_curr_pc, 
               src_b     => sig_one_4b,
               sum       => sig_next_pc,   
               carry_out => sig_pc_carry_out );
    
    insn_mem : instruction_memory 
    port map ( reset    => reset,
               clk      => clk,
               addr_in  => sig_curr_pc,
               insn_out => sig_insn );
    
    mux_branch_pc : mux_2to1_4b 
    port map ( mux_select => ex_mem_bne_taken,    
               data_a     => sig_next_pc,            
               data_b     => ex_mem_branch_target,   
               data_out   => sig_pc_in );
               
-- Instruction Decode (ID) Stage
    ctrl_unit : control_unit 
    port map ( opcode     => if_id_insn(15 downto 12),
               reg_dst    => sig_reg_dst,
               reg_write  => sig_reg_write,
               alu_src    => sig_alu_src,
               mem_write  => sig_mem_write,
               mem_to_reg => sig_mem_to_reg,
               in_to_reg  => sig_in_to_reg,
               sat_enable => sig_sat_enable,
               led_write  => sig_led_write,
               branch_bne => sig_branch_bne,
               dis_write  => sig_dis_write );

    mux_reg_dst : mux_2to1_4b 
    port map ( mux_select => sig_reg_dst,
               data_a     => if_id_insn(7 downto 4),
               data_b     => if_id_insn(3 downto 0),
               data_out   => sig_write_register );
               
    sign_extend : sign_extend_4to16 
    port map ( data_in    => if_id_insn(3 downto 0),
               data_out   => sig_sign_extended_offset );
               
 -- Execute (EX) Stage              
               
    mux_alu_src : mux_2to1_16b 
    port map ( mux_select => id_ex_ctrl_alu_src,
               data_a     => id_ex_read_data_b,
               data_b     => id_ex_imm,
               data_out   => sig_alu_src_b );

    alu : adder_16b 
    port map ( src_a      => id_ex_read_data_a,
               src_b      => sig_alu_src_b,
               sat_enable => id_ex_ctrl_sat_enable,
               sum        => sig_alu_result,
               carry_out  => sig_alu_carry_out );
               
    branch_adder : adder_4b
    port map ( src_a      => id_ex_pc, 
               src_b      => id_ex_imm(3 downto 0), 
               sum        => sig_branch_target,   
               carry_out  => open );
               
 -- Memory (MEM) Stage    
       
    data_mem : data_memory 
    port map ( reset        => reset,
               clk          => clk,
               write_enable => ex_mem_ctrl_mem_write,
               write_data   => ex_mem_read_data_b,
               addr_in      => ex_mem_alu_result(3 downto 0),
               data_out     => sig_data_mem_out );
               
               
 -- Write Back (WB) Stage
    mux_mem_to_reg : mux_2to1_16b 
    port map ( mux_select => mem_wb_ctrl_mem_to_reg,
               data_a     => mem_wb_alu_result,
               data_b     => mem_wb_mem_data,
               data_out   => sig_mem_mux_out );

    mux_sw_to_reg : mux_2to1_16b 
    port map ( mux_select => mem_wb_ctrl_in_to_reg,
               data_a     => sig_mem_mux_out,
               data_b     => sw,
               data_out   => sig_write_data );

    reg_file : register_file 
    port map ( reset           => reset, 
               clk             => clk,
               read_register_a => if_id_insn(11 downto 8),
               read_register_b => if_id_insn(7 downto 4),
               read_data_a     => sig_read_data_a,
               read_data_b     => sig_read_data_b,
               write_enable    => sig_reg_write_gated,
               write_register  => mem_wb_write_reg,
               write_data      => sig_write_data );
    
    mux_stall_pc : mux_2to1_4b 
    port map ( mux_select => sig_freeze_pc,
               data_a     => sig_pc_in,       
               data_b     => sig_curr_pc,     
               data_out   => sig_pc_stall_out );
    led_latch : process (reset, clk) is 
    begin 
        if (reset = '1') then
            led(14 downto 0) <= (others => '0');
        elsif (falling_edge(clk) and mem_wb_ctrl_led_write = '1') then
            led(14 downto 0) <= mem_wb_read_data_b(14 downto 0);
        end if;
    end process;
    
    led(15) <= sig_flag;

    dis_latch : process (reset, clk) is 
    begin 
        if (reset = '1') then
            sig_cop1 <= (others => '0');
            sig_cop2 <= (others => '0');
            sig_flag <= '0';
        elsif (falling_edge(clk) and id_ex_ctrl_dis_write = '1') then
            sig_cop1 <= sig_alu_result; 
            sig_cop2 <= id_ex_read_data_b; -- Use the pipeline register!
            sig_flag <= '1';
        end if;
    end process;
    
pipeline_registers: process(clk, reset)
    begin
        if reset = '1' then
if_id_pc <= (others => '0');
            if_id_insn <= (others => '0');
            id_ex_ctrl_reg_write <= '0';
            id_ex_ctrl_dis_write <= '0';
            ex_mem_ctrl_reg_write <= '0';
            mem_wb_ctrl_reg_write <= '0';
            ex_mem_bne_taken      <= '0';
            id_ex_ctrl_branch     <= '0';
            id_ex_ctrl_mem_write  <= '0';
            id_ex_ctrl_mem_to_reg <= '0';
            
        elsif rising_edge(clk) then
            if sig_step_pulse = '1' then
                
                -- EX/MEM Stage Update
                ex_mem_alu_result     <= sig_alu_result;
                ex_mem_read_data_b    <= id_ex_read_data_b;
                ex_mem_write_reg      <= id_ex_write_reg;
                ex_mem_branch_target  <= sig_branch_target;
                ex_mem_bne_taken      <= sig_bne_taken;
                ex_mem_ctrl_led_write <= id_ex_ctrl_led_write;
                ex_mem_ctrl_reg_write <= id_ex_ctrl_reg_write;
                ex_mem_ctrl_mem_write <= id_ex_ctrl_mem_write;
                ex_mem_ctrl_mem_to_reg<= id_ex_ctrl_mem_to_reg;
                ex_mem_ctrl_in_to_reg <= id_ex_ctrl_in_to_reg;

                -- MEM/WB Stage Update
                mem_wb_alu_result     <= ex_mem_alu_result;
                mem_wb_mem_data       <= sig_data_mem_out;
                mem_wb_write_reg      <= ex_mem_write_reg;
                mem_wb_ctrl_reg_write <= ex_mem_ctrl_reg_write;
                mem_wb_ctrl_mem_to_reg<= ex_mem_ctrl_mem_to_reg;
                mem_wb_ctrl_in_to_reg <= ex_mem_ctrl_in_to_reg;
                mem_wb_ctrl_led_write <= ex_mem_ctrl_led_write;
                mem_wb_read_data_b    <= ex_mem_read_data_b;
                
                if ex_mem_bne_taken = '1' then
                    if_id_pc   <= (others => '0');
                    if_id_insn <= (others => '0'); 
                    
                    id_ex_ctrl_reg_write  <= '0';
                    id_ex_ctrl_mem_write  <= '0';
                    id_ex_ctrl_mem_to_reg <= '0';
                    id_ex_ctrl_branch     <= '0';
                    id_ex_ctrl_dis_write  <= '0';
                    id_ex_ctrl_led_write  <= '0';
                    
                elsif sig_stall = '1' then                
                    id_ex_ctrl_reg_write  <= '0';
                    id_ex_ctrl_mem_write  <= '0';
                    id_ex_ctrl_branch     <= '0';
                    id_ex_ctrl_dis_write  <= '0';
                    id_ex_ctrl_led_write  <= '0';
                    
                else
                    if_id_pc   <= sig_next_pc;  
                    if_id_insn <= sig_insn;     
                    
                    id_ex_pc              <= if_id_pc;
                    id_ex_read_data_a     <= sig_read_data_a;
                    id_ex_read_data_b     <= sig_read_data_b;
                    id_ex_imm             <= sig_sign_extended_offset;
                    id_ex_write_reg       <= sig_write_register;
                    
                    id_ex_ctrl_led_write  <= sig_led_write;
                    id_ex_ctrl_reg_write  <= sig_reg_write;
                    id_ex_ctrl_mem_write  <= sig_mem_write;
                    id_ex_ctrl_mem_to_reg <= sig_mem_to_reg;
                    id_ex_ctrl_alu_src    <= sig_alu_src;
                    id_ex_ctrl_branch     <= sig_branch_bne;
                    id_ex_ctrl_sat_enable <= sig_sat_enable;
                    id_ex_ctrl_in_to_reg  <= sig_in_to_reg;
                    id_ex_ctrl_dis_write  <= sig_dis_write;
                end if;
            end if;
        end if;
    end process;
    
    
    button_debounce_and_edge: process(clk)
    begin
                if rising_edge(clk) then
            sig_btn_sync_1 <= btnC;
            sig_btn_sync_2 <= sig_btn_sync_1;
            
            if sig_btn_sync_2 = '1' then
                if debounce_counter < 10 then
                    debounce_counter <= debounce_counter + 1;
                else
                    sig_btn_clean <= '1'; 
                end if;
            else
                debounce_counter <= 0;
                sig_btn_clean <= '0';     
            end if;
            
            sig_btn_last <= sig_btn_clean;
            
            if (sig_btn_clean = '1' and sig_btn_last = '0') then
                sig_step_pulse <= '1';
            else
                sig_step_pulse <= '0';
            end if;
        end if;
    end process;
end structural;
